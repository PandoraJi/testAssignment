﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using voter_assignment.core.contracts;
using voter_assignment.infrastructure.Services;

namespace voter_assignment.infrastructure.Database
{
    public class Database : IDatabase
    {
        public readonly ConnectionStrings connectionStrings;
        public Database(ConnectionStrings _connectionStrings)
        {
            _connectionStrings = connectionStrings;
        }

       

        public async Task<TCommandStatus> ExecuteCommandAsync<TCommandStatus>(SqlCommand command)
        {
            await using var connection = GetCommandConnection();
            command.Connection = connection;
            await connection.OpenAsync();
            command.CommandType = System.Data.CommandType.StoredProcedure;
            object returnValue = await command.ExecuteNonQueryAsync();
            return (TCommandStatus)returnValue;
        }

        public Task<TCommandStatus> ExecuteCommandAsync<TCommandStatus>(CustomSqlCommand command) where TCommandStatus : new()
        {
            throw new NotImplementedException();
        }

        public Task<int> ExecuteNonQueryAsync(SqlCommand queryCommand)
        {
            throw new NotImplementedException();
        }

        public async Task<List<TQueryResult>> ExecuteQueryAsync<TQueryResult>(SqlCommand query) where TQueryResult : new()
        {
            var result = new List<TQueryResult>();
            await using var connection = GetQueryConnection();
            query.Connection = connection;
            await connection.OpenAsync();
            query.Prepare();
            var reader = (await query.ExecuteReaderAsync());
            while (await reader.ReadAsync())
            {
                
            }

            
        }

        public Task<List<TQueryResult>> ExecuteScalerQueryAsync<TQueryResult>(SqlCommand query) where TQueryResult : IConvertible
        {
            throw new NotImplementedException();
        }


        public SqlConnection GetCommandConnection()
        {
            return new SqlConnection(connectionStrings.CommandConnectionString);
        }
        public SqlConnection GetQueryConnection()
        {
            return new SqlConnection(connectionStrings.QueriesConnectionString);
        }
        public SqlConnection GetErrorConnection()
        {
            return new SqlConnection(connectionStrings.ErrorConnectionString);
        }
        public SqlConnection GetSecurityConnection()
        {
            return new SqlConnection(connectionStrings.SecurityConnectionString);
        }

    }
}
