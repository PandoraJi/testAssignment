﻿using System;

namespace voter_assignment.infrastructure
{
    public class Class1
    {
    }
}
