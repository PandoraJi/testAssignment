﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace voter_assignment.infrastructure.Services
{
   public static class RegisterCommandQueries
    {
        public static void AddHandlerAndQueries(this IServiceCollection services)
        {
            services.AddMediatR(Assembly.GetExecutingAssembly());
        }
    }
}
