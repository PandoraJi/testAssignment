﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using voter_assignment.core.contracts;

namespace voter_assignment.infrastructure.Services
{
   public sealed class ConnectionStrings
    {
        private readonly IOptions<DatabaseConnections> databaseConnections;
        private string commandConnectionString;
        private string queryConnectionString;
        private string securityConnectionString;
        private string errorConnectionString;
        private string reportConnectionString;

        public ConnectionStrings(IOptions<DatabaseConnections> _databaseConnections)
        {
            this.databaseConnections = _databaseConnections;
        }

        public string CommandConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(commandConnectionString))
                    commandConnectionString = databaseConnections.Value.CommandConnection;
                return commandConnectionString
            }
        }
        public string QueriesConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(queryConnectionString))
                    queryConnectionString = databaseConnections.Value.QueryConnection;
                return queryConnectionString;
            }
        }
        public string ErrorConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(errorConnectionString))
                    errorConnectionString = databaseConnections.Value.ErrorConnection;
                return errorConnectionString;
            }
        }

        public string SecurityConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(securityConnectionString))
                    securityConnectionString = databaseConnections.Value.SecurityConnection;
                return securityConnectionString;
            }
        }
    }
}
