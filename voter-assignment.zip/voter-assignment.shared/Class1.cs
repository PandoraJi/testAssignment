﻿using System;

namespace voter_assignment.shared
{
    public class Class1
    {
    }
}
