﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace voter_assignment.core.contracts
{
   public class DatabaseConnections
    {
        public string CommandConnection { get; set; }
        public string QueryConnection { get; set; }
        public string SecurityConnection { get; set; }
        public string ErrorConnection { get; set; }
        public string ReportConnection { get; set; }
    }
}
