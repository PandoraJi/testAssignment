﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace voter_assignment.core.contracts
{
    public interface IDatabase
    {
        Task<TCommandStatus> ExecuteCommandAsync<TCommandStatus>(SqlCommand command);
        Task<List<TQueryResult>> ExecuteQueryAsync<TQueryResult>(SqlCommand query) where TQueryResult:new();
        Task<TCommandStatus> ExecuteCommandAsync<TCommandStatus>(CustomSqlCommand command) where TCommandStatus : new();
        Task<List<TQueryResult>> ExecuteScalerQueryAsync<TQueryResult>(SqlCommand query) where TQueryResult : IConvertible;
        Task<int> ExecuteNonQueryAsync(SqlCommand queryCommand);

    }
}
