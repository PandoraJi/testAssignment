﻿using System.Data;

namespace voter_assignment.core.contracts
{
    public class CustomSqlCommand
    {
        public string CommandText { get; set; }
        public string Params { get; set; }
        public CommandType? CommandType { get; set; }
    }
}