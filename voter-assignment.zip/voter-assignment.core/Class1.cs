﻿using System;

namespace voter_assignment.core
{
    public class Class1
    {
    }
}
